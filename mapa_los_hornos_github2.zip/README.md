# 🗺 Mapa Interactivo – Los Hornos, La Plata

Visor web interactivo de capas geográficas para el área de **Los Hornos**, Partido de La Plata, Argentina.

## 🌐 Ver el mapa

👉 **[Abrir mapa](https://TU-USUARIO.github.io/TU-REPO/)**

## 📂 Capas disponibles

### Actividades Municipales
- Barrido, Limpieza, Pasto, Recolección por trimestre (T4/2024 – T1/2026)
- Estilos graduados por cantidad de registros

### Indicadores Sociales (Censo)
- NBI, Hacinamiento, IPMH
- Agua, Saneamiento, Combustible
- Densidad 2010-2022, Edad, Clima Educativo

### Estructura Urbana
- Red vial (calles, análisis, red primaria)
- Parcelas urbanas/rurales

### Equipamientos
- Establecimientos educativos
- Centros de salud
- Seguridad (eventos)
- Unidades penitenciarias

## 🚀 Publicar en GitHub Pages

1. Subir todos los archivos a un repositorio de GitHub
2. Ir a **Settings → Pages**
3. En *Source* seleccionar la rama `main` y carpeta `/ (root)`
4. Guardar. En unos minutos el mapa estará disponible en `https://TU-USUARIO.github.io/TU-REPO/`

## 🛠 Tecnologías

- [Leaflet.js](https://leafletjs.com/) — mapa interactivo
- GeoJSON — formato de capas
- GitHub Pages — hosting gratuito
